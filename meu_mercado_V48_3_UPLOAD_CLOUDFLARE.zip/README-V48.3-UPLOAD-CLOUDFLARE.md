# Meu Mercado V48.3 — Upload direto pelo painel do Cloudflare

Esta versão foi preparada especificamente para o upload direto pelo painel do Cloudflare.

## Esta versão NÃO usa
- `wrangler.jsonc`
- `wrangler.toml`
- `package.json`
- etapa de build
- Worker externo separado para a IA

## Estrutura
- `_worker.js` = Worker principal + rotas `/api/*`
- `index.html` = aplicativo
- `firebase-config.js` = Firebase
- `sw.js` = cache atualizado
- ícones e manifest = PWA

## IA
A aplicação usa exclusivamente o mesmo domínio para:
- `/api/ai-status`
- `/api/identify-product`
- `/api/read-receipt`

Não há URL externa de Worker salva no código. Se havia um endereço antigo salvo no telefone, esta versão o ignora e remove essa configuração.

Depois de publicar, configure no Worker pelo painel pelo menos UMA opção:

### Opção A — Workers AI
Binding com o nome exato:
`AI`

### Opção B — Gemini
Secret com o nome exato:
`GEMINI_API_KEY`

O `_worker.js` tenta Workers AI primeiro e Gemini como fallback.

## Teste
Abra no endereço publicado:
`/api/ai-status`

O JSON deve retornar `ok: true` quando pelo menos um provedor de IA estiver configurado.

## Firebase
O Firebase permanece no aplicativo.

## Importante
Este pacote é para o método de upload direto pelo painel. Para `wrangler deploy` ou Workers Builds, use uma configuração Wrangler própria.
