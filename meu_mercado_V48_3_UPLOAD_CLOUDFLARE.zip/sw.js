// Meu Mercado V48.3 — Service Worker sem cache de aplicação.
// Mantém o navegador sempre buscando a versão publicada no Cloudflare.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));
